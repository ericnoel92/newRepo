console.log('bonjour');
document.addEventListener("DOMContentLoaded", function () {
    
    function convertCurrency() {
        
    }

    
    document.getElementById("convertBtn").addEventListener("click", convertCurrency);
});
